library(mvtnorm)
library(matrixStats)
library(geoR)

# Transform that to matern parameters
theta2mat <- function(theta,nugget=TRUE){
  c(exp(theta[1]),
    ifelse(nugget,1/(1+exp(-theta[2])),1),
    exp(theta[3]),
    exp(theta[4]))
}

# Transform matern parameters to theta
mat2theta <- function(mat,nugget=TRUE){
  c(log(mat[1]),
    ifelse(nugget,log(mat[2]/(1-mat[2])),Inf),
    log(mat[3]),
    log(mat[4]))
}

simulateMatern <- function(theta, d){
  thetan <- rep(0, 4)
  temp <- theta2mat(theta)
  thetan[1] <- temp[1]*(1-temp[2])
  thetan[2] <- temp[1]*temp[2]
  thetan[3:4] <- temp[3:4]
  Var <- thetan[2] * matern(d, thetan[3], thetan[4])
  diag(Var) <- diag(Var) + thetan[1]
  ret <- rmvnorm(1, sigma = Var)
  return(ret)
}

Maternvar <- function(theta, d){
  thetan <- rep(0, 4)
  temp <- theta2mat(theta)
  thetan[1] <- temp[1]*(1-temp[2])
  thetan[2] <- temp[1]*temp[2]
  thetan[3:4] <- temp[3:4]
  Var <- thetan[2] * matern(d, thetan[3], thetan[4])
  diag(Var) <- diag(Var) + thetan[1]
  return(Var)
}

updateBeta <- function(l, y, IVarc, Beta, IVare, X, B =  NULL){
  if(is.null(B)){B <- rep(1, n)}
  Beta.mean <- rowSums(sapply(1:m, function(k){diag((X[, k])*(B))%*%IVare%*%(y[, k])})) #rowSums((y - mean)*X[, l,])*(B)
  Beta.ivar <- lapply(1:m, function(k){diag((X[, k])*B)%*%IVare%*%diag((X[, k])*B)})
  Beta.ivar <- Reduce('+', Beta.ivar)+ IVarc
  Beta.var <- solve(Beta.ivar)
  Beta.var <- (Beta.var + t(Beta.var))/2
  Beta.mean <- Beta.var %*% Beta.mean
  gen <- rmvnorm(1, Beta.mean, Beta.var)
  return(gen)
}

################################################Function####################################################
      #' @title The function to fit image on image regression Y_i(s) = beta0(s) + beta1(s)X_i(s)
      #' @description Takes the response variable (Y), explanatory variable (X) and the number of components
      #' and spits out the posterior samples of beta
      #' @references Roy et. al. (2019)
      #'     "Spatial shrinkage via the product independent Gaussian process prior" arXiv 1805.03240
      #'
      #' @param Y is response matrix with each column, representing vectorized image at each replication
      #' @param X is explanatory matrix with each column, representing vectorized image at each replication
      #' @param q is the number of components in PING
      #' @param Total_sample is the total number of iterations of MCMC
      #' @param thin is the thinning parameter of the MCMC samples
      #' @param pri.mn is the prior mean of reparametrized Matern parameters
      #' @param pri.sd is the prior standard deviation of reparametrized Matern parameters

      #' @return image.image returns a list of the posterior samples of beta \cr
      #' \item{Beta_p}{The posterior samples of beta}
      #'
      #'
      #' @export
      #' @examples
#' n1 <- 50
#' n2 <- 50
#' n <- 100
#' c1       <- round(runif(n, 1, n1))
#' c2       <- round(runif(n, 1, n1))
#' #'dimvec <- c(n1, n2, n3)
#' buff     <- n1/8
#'
#' thetaA0 <- c(0,log(0.95/0.05),log(10),0)
#'
#' A1 <- rep(1:n2, each = n1)
#' A2 <- rep(1:n1, n2)
#' tempA <- cbind(A2, A1)
#' #'Ap <- matrix(rep(array(t(tempA)), n3), ncol=2, byrow = T)
#' Ap <- tempA #'cbind(Ap, rep(1:n3, each=n1*n2))
#'
#'
#' m       <- 20    #' Number of subjects
#' RE      <- TRUE  #' Generate data with random effects?
#'
#'
#'
#' L=1
#' MHY=.01
#'
#' X <- matrix(rnorm(n1*n2), n1)
#' M<-m
#'
#' #'MU_b  <- matrix(0,J,M)
#' tauQ  <- 1
#'
#' loc <- cbind(c1,c2)
#' dis <- as.matrix(dist(loc/50))
#'
#' B0  <- simulateMatern(thetaA0,dis)
#'
#' Beta0 <- matrix(0, n, 10)
#'
#' for(i in 1:5){
#'   Beta0[, i] <- rep(0, n)
#' }
#' layout(matrix(1:6, nrow = 2, byrow = T), respect = T)
#' uh <- round(runif(5,0,2)) + 1
#' for(i in 6:10){
#'   h <- uh[i-5]
#'   u <- matrix(runif(h*2), ncol = 2, nrow=h)
#'   d <- 2*exp(-3*rowSums((Ap-matrix(c(n1*u[1,1], n2*u[1,2]), nrow = nrow(Ap), 2, byrow=T) )^2)/50)
#'   if(h == 2){
#'     d <- 2*exp(-3*rowSums((Ap-matrix(c(n1*u[1,1], n2*u[1,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50) + 2*exp(-3*rowSums((Ap-matrix(c(n1*u[2,1], n2*u[2,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50)
#'   }
#'   if(h == 3){
#'     d <- 2*exp(-3*rowSums((Ap-matrix(c(n1*u[1,1], n2*u[1,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50) +
#'       2*exp(-3*rowSums((Ap-matrix(c(n1*u[2,1], n2*u[2,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50) + 2*exp(-3*rowSums((Ap-matrix(c(n1*u[3,1], n2*u[3,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50)
#'   }
#'
#'   B1  <- d
#'   B1[which(B1<1e-1)]<- 0
#'
#'   B1 <- matrix(B1, n1, n2)
#'   #'image(B1, col = tim.colors(), main = paste("Beta_",i,sep = ""))
#'   Beta0[, i] <- B1[loc]
#' }
#'
#' Beta0 <- Beta0[,1]
#'
#' X <- matrix(0, n, m)
#'
#' for(i in 1:1){
#'   thetat <- rnorm(4)
#'   for(k in 1:m){
#'     X[, k] <- simulateMatern(thetat, dis)
#'   }
#' }
#'
#'
#'       mean <- rowSums(X*Beta0)
#'       temp <- matrix(rep(B0, m), ncol = m) + mean
#'       temp <- mean((apply(temp, 1, sd))^2)
#'
#'       theta0  <- c(log(temp/10),log(0.90/0.10),log(10),0)
#'
#'       Ylist <- matrix(0, n, m)
#'
#'
#'       for(t in 1:m){
#'         Ylist[, t] <- B0 + rowSums(X*Beta0) + simulateMatern(theta0, dis)
#'       }
#'
#'       Beta <- matrix(0, n, 2)
#'
#'       Beta[, 1] <- B0
#'       Beta[, 2] <- Beta0
#' fit <- image.image(Y, X, Total_sample = 200)

      image.image <- function(Y, X, q = 5, Total_sample, thin = 1, pri.mn=c(0,0,0,0), pri.sd=c(10,2,10,1)){
        m <- ncol(Y)
        n <- nrow(Y)
        Beta <- rowMeans(Y)
        Beta <- cbind(Beta, rnorm(n))
        init.theta=c(0,2,2,0)
        theta <- matrix(init.theta, ncol = 4,nrow = (3),byrow=T)

        isdmat <- list()
        Betacom <- list()
        IVare <- solve(Maternvar(theta[1, ], dis))
        for(i in 1:3){
          isdmat[[i]] <- solve(Maternvar(theta[i, ], dis))
          if(i > 2){
            Ivar <- isdmat[[i]]
            y <- Y - matrix(rep(Beta[, 1], m), ncol = m)
            Beta.mean <- rowSums(sapply(1:m, function(k){diag((X[,k]))%*%IVare%*%(y[, k])}))
            Beta.ivar <- lapply(1:m, function(k){diag((X[,k]))%*%IVare%*%diag((X[,k]))})
            Beta.ivar <- Reduce('+', Beta.ivar) + Ivar
            Beta.var <- solve(Beta.ivar)
            Beta.var <- (Beta.var + t(Beta.var))/2
            Beta.mean <- Beta.var %*% Beta.mean
            Beta[, i-1] <- rmvnorm(1, Beta.mean, Beta.var)
            temp <- Beta[, i-1] #sqrt(abs(Betasp[, 2]))
            temp1 <- sign(temp)*(abs(temp))^(1/q)
            Betac <- matrix(rep(temp1, q), ncol = q)
          }
        }

        Total_itr <- Total_sample
        itr = 0
        Be0_p <- list()
        Be_p <- list()
        theta_p <- list()
        Beta_p <- list()
        acceptedthetano_p <- matrix(0, Total_itr, 3)
        accepteddeltamatno_p <- rep(0, Total_itr)
        accepteddeltano_p <- rep(0, Total_itr)

        tol=0.000001

        sdl <- rep(0.001, 3)
        sdl[1] <- 0.1
        pb <- txtProgressBar(min = itr, max = Total_itr, style = 3)
        while(itr < Total_itr){
          itr <- itr + 1
          flag <- rep(0, 3)
          IVare <- isdmat[[1]]
          Ivar <- isdmat[[2]]

          mean <- X * Beta[, 2]
          Beta.mean <- rowSums(IVare%*%(Y - mean))
          Beta.ivar <- m*IVare + Ivar
          Beta.var <- solve(Beta.ivar)
          Beta.var <- (Beta.var + t(Beta.var))/2
          Beta.mean <- (Beta.var %*% Beta.mean)
          Beta[, 1] <- rmvnorm(1, Beta.mean, Beta.var)

          if(q>1){
              Ivar <- (isdmat[[3]])
              for(k in 1:q){
                B <- Betac[, - k]
                if(q>2){
                  B <- rowProds(Betac[, - k])
                }
                Ivar <- Ivar*(k==1) + (Ivar/exp(theta[3, 1]))*(k>1)
                Betac[, k] <- updateBeta(i, Y-matrix(rep(Beta[, 1], m), ncol = m), Ivar, Beta, IVare, X, B)
              }

              Beta[, 2] <- rowProds(Betac)


            i=3
              thetaA <- theta[i, ]
              cant <- rep(0, 4)
              cant[-1]     <- thetaA[-1] + rnorm(3,sd = sdl[i]) #MH[2]*tCthetaA%*%
              cansd    <- solve(Maternvar(cant, dis))
              psd <- isdmat[[i]]    #Maternvar(thetaA, dis)
              y   <-     Betac
              bb       <- (t(y[, 1])%*%(cansd)%*%(y[, 1]))/2+.1
              cant1    <- -log(rgamma(1,n/2+.1,bb))
              cant[1]  <- cant1
              cansd    <- cansd/exp(cant1)
              BB       <- exp(thetaA[1])*(t(y[, 1])%*%(psd)%*%(y[, 1]))/2+.1

              term1    <- t(y[, 2])%*%psd%*%y[, 2]*exp(thetaA[1]) / 2

              if(q > 2){
                term1    <- sum(apply(y[, 2:q], 2, function(x){t(x)%*%psd%*%x*exp(thetaA[1])}))/2
              }

              term2    <- t(y[, 2])%*%cansd%*%y[, 2]*exp(cant[1]) / 2

              if(q > 2){
                term2    <- sum(apply(y[, 2:q], 2, function(x){t(x)%*%cansd%*%x*exp(cant[1])}))/2
              }

              curll    <- 0.5*as.numeric(determinant(psd)$modulus) + 0.5*(q-1)*as.numeric(determinant(psd*exp(thetaA[1]))$modulus)-
                (t(y[, 1])%*%(psd)%*%(y[, 1]))/2 - term1 +
                sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
                dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
              canll    <- 0.5*as.numeric(determinant(cansd)$modulus) + 0.5*(q-1)*as.numeric(determinant(cansd*exp(cant1))$modulus)-
                (t(y[, 1])%*%(cansd)%*%(y[, 1]))/2 - term2 +
                sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
                dgamma(exp(-cant[1]),.1,.1,log=TRUE)
              Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
              Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
              R        <- canll-curll+Q1-Q2
              if(!is.na(R)){if(log(runif(1))< R){
                flag[i] <- 1
                theta[i,]  <- cant
                isdmat[[i]]  <- cansd
              }}
          }

          if(q == 1){
            i=1
              Ivar <- isdmat[[i+2]]
              mean <- X*Beta[, 2]
              y <- Y - matrix(rep(Beta[, 1], m), ncol = m) - mean
              Beta.mean <- rowSums(sapply(1:m, function(k){diag((X[,k]))%*%IVare%*%(y[, k])}))
              Beta.ivar <- lapply(1:m, function(k){diag((X[,k]))%*%IVare%*%diag((X[,k]))})
              Beta.ivar <- Reduce('+', Beta.ivar) +  Ivar
              Beta.var <- solve(Beta.ivar)
              Beta.var <- (Beta.var + t(Beta.var))/2
              Beta.mean <- Beta.var %*% Beta.mean
              Beta[, i+1] <- rmvnorm(1, Beta.mean, Beta.var)


            i=3
              thetaA <- theta[i, ]
              cant <- rep(0, 4)
              cant[-1]     <- thetaA[-1] + rnorm(3,sd = sdl[i]) #MH[2]*tCthetaA%*%
              cansd    <- solve(Maternvar(cant, dis))
              psd <- isdmat[[i]]    #Maternvar(thetaA, dis)
              y <-     Beta[, i-1]
              bb       <- (t(y)%*%solve(cansd)%*%(y))/2+.1
              cant1    <- -log(rgamma(1,n/2+.1,bb))
              cant[1]  <- cant1
              cansd    <- cansd/exp(cant1)
              BB       <- exp(thetaA[1])*(t(y)%*%(psd)%*%(y))/2+.1

              curll    <- 0.5*as.numeric(determinant(psd)$modulus) - (t(y)%*%(psd)%*%(y))/2 +
                sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
                dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
              canll    <- 0.5*as.numeric(determinant(cansd)$modulus) - (t(y)%*%(cansd)%*%(y))/2 +
                sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
                dgamma(exp(-cant[1]),.1,.1,log=TRUE)
              Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
              Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
              R        <- canll-curll+Q1-Q2
              if(!is.na(R)){if(log(runif(1))< R){
                flag[i] <- 1
                theta[i,]  <- cant
                isdmat[[i]]  <- cansd
              }}
            }

          thetaA <- theta[1, ]
          cant <- rep(0, 4)
          cant[-1]     <- thetaA[-1] + rnorm(3,sd = sdl[1]) #MH[2]*tCthetaA%*%
          cansd    <- solve(Maternvar(cant, dis))
          psd <- isdmat[[1]]    #Maternvar(thetaA, dis)
          mean <- X*Beta[, 2]
          y <-     Y - matrix(rep(Beta[, 1], m), ncol = m) - mean
          bb       <- sum(apply(y, 2, function(x){t(x)%*%cansd%*%x}))/2+.1
          cant1    <- -log(rgamma(1,m*n/2+.1,bb))
          cant[1]  <- cant1
          cansd    <- cansd/exp(cant1)
          BB       <- exp(thetaA[1])*sum(apply(y, 2, function(x){t(x)%*%psd%*%x}))/2+.1

          curll    <- 0.5*m*as.numeric(determinant(psd)$modulus) - sum(apply(y, 2, function(x){t(x)%*%psd%*%x}))/2+
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- 0.5*m*as.numeric(determinant(cansd)$modulus) - sum(apply(y, 2, function(x){t(x)%*%cansd%*%x}))/2+
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),m*n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),m*n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[1] <- 1
            theta[1,]  <- cant
            isdmat[[1]]  <- cansd
          }}

          thetaA <- theta[2, ]
          cant <- rep(0, 4)
          cant[-1]     <- thetaA[-1] + rnorm(3,sd = sdl[2]) #MH[2]*tCthetaA%*%
          cansd    <- solve(Maternvar(cant, dis))
          psd <- isdmat[[2]]    #Maternvar(thetaA, dis)
          y <-     Beta[, 1]
          bb       <- (t(y)%*%solve(cansd)%*%(y))/2+.1
          cant1    <- -log(rgamma(1,n/2+.1,bb))
          cant[1]  <- cant1
          cansd    <- cansd/exp(cant1)
          BB       <- exp(thetaA[1])*(t(y)%*%(psd)%*%(y))/2+.1

          curll    <- 0.5*as.numeric(determinant(psd)$modulus) - (t(y)%*%(psd)%*%(y))/2 +
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- 0.5*as.numeric(determinant(cansd)$modulus) - (t(y)%*%(cansd)%*%(y))/2 +
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[2] <- 1
            theta[2,]  <- cant
            isdmat[[2]]  <- cansd
          }}
          acceptedthetano_p[itr, ] <- flag
          if(itr%%thin == 0){
            Beta_p[[itr/thin]] <- Beta
          }

          if(itr %% 100 == 0){
            for(l in 1:3){
              if(mean(acceptedthetano_p[1:itr,l]) > 0.45){sdl[l] <- sdl[l]*1.2}
              if(mean(acceptedthetano_p[1:itr,l]) < 0.3){sdl[l] <- sdl[l]*0.8}
            }
          }
          Sys.sleep(0.1)
          # update progress bar
          setTxtProgressBar(pb, itr)
        }
        close(pb)
        return(Beta_p)
      }
