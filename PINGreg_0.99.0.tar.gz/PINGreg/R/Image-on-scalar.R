library(mvtnorm)
library(matrixStats)
library(geoR)
##################################################################################

greal <- function(dim){ #get_real
  B = 0
  ind=0
  yf <- c(1,2)
  tol <- 1e-9
  m <- 1 - dim %% 2

  while(sum(yf)!=(prod(dim) - prod(2^m))/2 | length(ind)!=sum(yf)){
    yf <- rep(0, prod(dim))
    #while(length(unique(B))<prod(dim)){
    B <- array(rnorm(prod(dim),sd=length(dim)*exp(mean(log(dim)))), dim)
    #}

    Bfft <- fft(B)/sqrt(prod(dim))
    #bfa <- bfa/4
    bfa <- array(Re(Bfft))
    tem <- cbind(bfa, 1:prod(dim))
    tem <- tem[order(tem[,2]),]
    tem <- tem[order(tem[,1]),]
    tem1 <- tem[2:prod(dim),1] - tem[1:(prod(dim)-1),1]
    c <- which(abs(tem1)<tol)
    c1 <- (tem[c+1,2] < tem[c,2])
    yf[tem[c[c1], 2]] <- 1
    yf[tem[c[!c1]+1,2]]<-1

    yf <- as.logical(yf)

    clust <- rep(0, prod(dim))
    clust[!yf] <- 1:sum(!yf)

    c2 <- bfa[yf]
    ind <- sort(union(tem[c[c1]+1, 2], tem[c[!c1],2]))
    tol <- tol/10
  }

  temp1 <- cbind(bfa[ind], clust[ind])
  temp2 <- cbind(c2, which(yf==T))
  temp1 <- temp1[order(temp1[,1]),]
  temp2 <- temp2[order(temp2[,1]),]
  clust[temp2[, 2]] <- temp1[,2]

  return(list(realindex = 1 - yf, clustervec = clust))
}




tilda <- function(grealout, xf){
  id <- grealout$realindex
  xtilda <- array(0, prod(dim(xf)))
  xtilda[as.logical(id)] <- array(Re(xf))[as.logical(id)]
  xtilda[!id] <- array(Im(xf))[!id]
  xtilda <- array(xtilda, dim(xf))
}

recon1 <- function(grealout, xtilda){
  id <- grealout$realindex
  clust <- grealout$clustervec
  id <- as.logical(id)
  y <- xtilda[id]
  im <- xtilda[!id]
  imtotal <- array(0, prod(dim(xtilda)))
  realtotal <- y[clust]
  imtotal[!id] <- im
  c1 <- id*clust
  c2 <- clust[!id]
  ind <- which(c1 %in% c2)
  c2y <- cbind(c2, im)
  c2y <- c2y[order(c2y[,1]),]
  imtotal[ind] <- - c2y[,2]
  return(array(complex(real=realtotal,imaginary=imtotal), dim(xtilda)))
}


convert1 <- function(x,gout=NULL,inv=FALSE){
  if(is.null(gout)){
    gout <- greal(dim(x))
  }
  if(inv==FALSE){
    y <- fft(x)/sqrt(prod(dim(x)))
    y <- tilda(gout, y)
  }
  if(inv==TRUE){
    y <- recon1(gout,x)
    y <- Re(fft(y,inv=T))/sqrt(prod(dim(x)))
  }
  return(y)}

FFT <- function(Y, dimvec = dim(Y)){
  Y <- array(Y, dimvec)
  fft(Y)/sqrt(prod(dim(Y)))
}

IFFT <- function(Y, dimvec = dim(Y)){
  Y <- array(Y, dimvec)
  fft(Y,inverse=TRUE)/sqrt(prod(dim(Y)))
}

homega3D <- function(dim){ #make.delta2D
  n1 <- dim[1]
  n2 <- dim[2]
  n3 <- dim[3]
  omega1 <- 2*pi*(seq(0,n1-1,1))/n1
  omega2 <- 2*pi*(seq(0,n2-1,1))/n2
  omega3 <- 2*pi*(seq(0,n3-1,1))/n3

  #create matrix each column represent co-ordinate of col-major 3D matrix
  A1 <- rep(1:n2, each = n1)
  A2 <- rep(1:n1, n2)
  tempA <- cbind(A2, A1)
  A <- matrix(rep(array(t(tempA)), n3), ncol=2, byrow = T)
  A <- cbind(A, rep(1:n3, each=n1*n2))

  omegacombine <- rbind(omega1[A[,1]],omega2[A[,2]], omega3[A[,3]])

  h <- colSums((sin(omegacombine/2))^2)
  return(h)
}

# Transform that to matern parameters
theta2mat <- function(theta,nugget=TRUE){
  c(exp(theta[1]),
    ifelse(nugget,1/(1+exp(-theta[2])),1),
    exp(theta[3]),
    exp(theta[4]))
}

# Transform matern parameters to theta
mat2theta <- function(mat,nugget=TRUE){
  c(log(mat[1]),
    ifelse(nugget,log(mat[2]/(1-mat[2])),Inf),
    log(mat[3]),
    log(mat[4]))
}

# Matern spectral density
spec_d_matern <- function(delta,theta,dim,d=2,nugget=TRUE, whichreal){
  pars     <- theta2mat(theta,nugget)
  num      <- -(pars[4]+d/2)
  den      <- 1/pars[3]^2+delta/4 #why delta/4?
  f        <- den^num
  f        <- prod(dim)*f/sum(f) #why this normalization?
  f        <- (1-pars[2]) + pars[2]*f
  f            <- pars[1]*f
  f[whichreal] <- f[whichreal]/2
  return(f)}

simulateMatern <- function(specd,dim){
  Z     <- array(rnorm(prod(dim)),dim)
  y     <- sqrt(specd)*FFT(Z)
  Y     <- Re(IFFT(y))
  return(Y)}

impute <- function(Y.o, mu,miss,specd, dimvec,tol,gout,maxiter){
  Y.o <- array(Y.o, dimvec)
  mu <- array(mu, dimvec)
  miss <- array(miss, dimvec)
  Y.o  <- mu+update.Y(Y.o-mu,miss,specd, dimvec,tol=tol,maxiter=maxiter)
  dat  <- convert1(array(Y.o,dimvec),gout)
  return(dat)}

condExp <- function(Arr,A,miss, dimvec,specd,maxiter=50,tol=0.1){
  xArr         <- 0*specd
  xArr[!miss]  <- pcg(A,Arr,miss, dimvec,specd,maxiter=maxiter,tol=tol)
  ArrImp       <- A(xArr,miss,specd, dimvec, all=TRUE)
  return(ArrImp)}



A <- function(y,miss,specd, dimvec, all=FALSE){
  y[miss] <- 0
  x       <- Re(IFFT(sqrt(specd)*FFT(y,dimvec),dimvec))
  if(!all){x<-x[!miss]}
  return(x)}



pcg <-function(A,yArr,miss,dimvec,specd,maxiter=1e4,tol=1e-1){

  # A is forward multiplication, takes in an array

  # we define the preconditioner to be A with 1/specden

  # if * denotes a vector, *Arr denotes corresp. array with zeros or NAs
  # in place of missing value locations

  y     = yArr[!miss]

  x     = rep(0,sum(!miss))
  xArr  = array(0,dimvec)
  xArr[!miss] <- x;
  r     = y-A(xArr,miss,specd, dimvec)
  z     = A(yArr,miss,1/specd, dimvec)
  p     = z
  iter  = 0
  pArr <- array(0,dimvec)
  r1Arr <- array(0,dimvec)
  while (mean(r^2)>tol & iter<maxiter){
    iter  = iter+1
    pArr[!miss] <- p
    Ap    = A(pArr,miss,specd, dimvec)
    a     = sum(r*z)/sum(p*Ap)
    x     = x+a*p
    r1    = r-a*Ap
    r1Arr[!miss] <- r1
    z1    = A(r1Arr,miss,1/specd, dimvec)
    bet   = sum(z1*r1)/sum(z*r)
    p     = z1+bet*p
    z     = z1
    r     = r1
  }
  return(x)}

update.Y <- function(Y,miss,specd, dimvec,maxiter=50,tol=0.1){
  YcondExp     <- condExp(Y,A,miss, dimvec,specd,maxiter=maxiter,tol=tol)
  eArr         <- simulateMatern(specd,dimvec)
  econdExp     <- condExp(eArr,A,miss, dimvec,specd,maxiter=maxiter,tol=tol)
  Y[miss]      <- YcondExp[miss] + eArr[miss]-econdExp[miss]
  return(Y)}

##############################################################################


updatetheta <- function(l, y, theta, sdl1){
  n <- prod(dimvec)
  y <- y[,l]
  speccur <- SPECD
  if(l>1)
  {speccur <- SPECDC[,l-1]}
  flag = 0
  thetaA <- theta[l, ]
  cant     <- thetaA[-1] + rnorm(3,sd = sdl1) #MH[2]*tCthetaA%*%
  cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
  #bb       <- sum(y/cansd)/2+.1
  #cant1    <- -log(rgamma(1,n/2+.1,bb))
  aaa       <- 1/sdl1
  bbb       <- 1/sdl1
  cant1    <- -log(rgamma(1,aaa,bbb/exp(-thetaA[1])))
  cant     <- c(cant1,cant)
  #cansd    <- exp(cant1)*cansd
  #BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

  curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
    sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
    dcauchy(exp(-thetaA[1]),scale = delta[l-2],log=TRUE)#dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
  canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
    sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
    dcauchy(exp(-cant[1]),scale = delta[l-2],log=TRUE)#dgamma(exp(-cant[1]),.1,.1,log=TRUE)
  Q1       <- dgamma(exp(-cant1),aaa,bbb/exp(-thetaA[1]),log=TRUE)#dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
  Q2       <- dgamma(exp(-thetaA[1]),   aaa,bbb/exp(-cant1),log=TRUE)#dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
  R        <- canll-curll+Q1-Q2
  if(!is.na(R)){if(log(runif(1))< R){
    flag <- 1
    theta[l, ]  <- cant
    SPECDA  <- cansd
    curll <- canll
  }}
  if(l>1){
    SPECDC[,l-1] <- cansd
  }
  else{
    SPECD <- cansd
  }

  return(list(flag=flag, theta=thetaA))
}

updatetheta1 <- function(l, y, theta, sdl1){
  n <- prod(dimvec)
  y <- y[,l]
  speccur <- SPECD
  if(l>1)
  {speccur <- SPECDC[,l-1]}
  flag = 0
  thetaA <- theta[l, ]
  cant     <- thetaA[-1] + rnorm(3,sd = sdl1) #MH[2]*tCthetaA%*%
  cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
  bb       <- sum(y/cansd)/2+.1
  cant1    <- -log(rgamma(1,n/2+.1,bb))
  cant     <- c(cant1,cant)
  cansd    <- exp(cant1)*cansd
  BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

  curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
    sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
    dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
  canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
    sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
    dgamma(exp(-cant[1]),.1,.1,log=TRUE)
  Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
  Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
  R        <- canll-curll+Q1-Q2
  if(!is.na(R)){if(log(runif(1))< R){
    flag <- 1
    thetaA  <- cant
    SPECDA  <- cansd
    curll <- canll
  }}
  if(l>1){
    SPECDC[,l-1] <- cansd
  }
  if(l==1){
    SPECD <- cansd
  }

  return(list(flag=flag, theta=thetaA))
}


updatebeta <- function(l, Beta){
  mean1     <- Beta[ch.omega, ]
  mean1 <- mean1[, l]
  SPECDl <- SPECDC[ch.omega, ]
  SPECDl <- SPECDl[, l]
  mean <- mean1/SPECDl
  mean <- (t(B[ch.omega,])%*%mean)
  betavar <- solve(diag(1/deltamat[, l]) + crossprod(B[ch.omega, ])*sum(1/SPECDl))
  mean <- betavar%*%array(mean)
  betal <- rmvnorm(1, mean, betavar)
  return(betal)
}

updateBetaomega <- function(omegaid, y){
  Betaomega.mean1 <- colSums(matrix(y[omegaid, ],nrow = nrow(X), ncol = ncol(X), byrow = T)*X) / SPECD[omegaid]
  Betaomega.mean2 <- B[omegaid, ] %*% beta /SPECDC[omegaid, ]
  Betaomega.var <- solve(CX/SPECD[omegaid] + sum(1/SPECDC[omegaid, ]))
  Betaomega.mean <- Betaomega.var%*%array(Betaomega.mean1+Betaomega.mean2)
  Betaomega <- rmvnorm(1, Betaomega.mean, Betaomega.var)
  return(Betaomega)
}

updateBeta <- function(l, y, SPECDCa, Beta, SPECD, X, B, n){
  Beta.mean1 <- rowSums((y - Beta[,-l]%*%t(X[,-l]))*matrix(X[,l], nrow=nrow(y),ncol=ncol(y),byrow=T)) / SPECD
  #Beta.mean2 <- B %*% beta[, l] /SPECDC[, l]
  Beta.var <- array(sum(X[,l]^2) / SPECD + 1 / SPECDCa)
  Beta.mean <- array(Beta.mean1) #+ array(Beta.mean2)
  gen <- rnorm(n, Beta.mean/Beta.var, sqrt(1/Beta.var))
  return(gen)
}


updatebeta1 <- function(l, y, Beta){
  mean1     <- rowSums((y - Beta[,-l]%*%t(X[,-l]))*matrix(X[,l], nrow=nrow(y),ncol=ncol(y),byrow=T)) / SPECD
  mean <- (t(B)%*%mean1)
  betavar <- solve(diag(1/deltamat[, l]) + sum(X[,l]^2)*crossprod(B/sqrt(SPECD)))
  mean <- betavar%*%array(mean)
  betal <- rmvnorm(1, mean, betavar)
  return(betal)
}

updatedeltamat <- function(l, deltamat, delta, sdl2){
  flag      <- 0
  sig       <- deltamat[, l]
  #s0        <- 1/sqrt(taub[q+1])
  aaa       <- 1/sdl2
  bbb       <- 1/sdl2
  cansig    <- rgamma(J,aaa,bbb/sig)
  lp1       <- dnorm(beta[, l],0,cansig,log=TRUE) + dcauchy(cansig,scale = delta[l],log=TRUE)
  lp2       <- dnorm(beta[, l],0,sig,   log=TRUE) + dcauchy(   sig,scale = delta[l],log=TRUE)
  lq1       <- dgamma(cansig,aaa,bbb/sig,log=TRUE)
  lq2       <- dgamma(sig,   aaa,bbb/cansig,log=TRUE)
  R         <- lp1-lp2+lq2-lq1
  R         <- (log(runif(J))<R)
  sig       <- ifelse(R,cansig,sig)
  flag      <- (flag+sum(R))/length(R)
  deltamat[, l] <- array(sig)
  return(flag)
}

updatedelta <- function(l, deltamat, delta, sdl3){
  flag      <- 0
  sig       <- delta[l]
  aaa       <- 1/sdl3
  bbb       <- 1/sdl3
  cansig    <- rgamma(1,aaa,bbb/sig)
  lp1       <- sum(dcauchy(deltamat[l],0,cansig,log=TRUE) + dgamma(1/cansig,0.1,0.1,log=TRUE))
  lp2       <- sum(dcauchy(deltamat[l],0,   sig,log=TRUE) + dgamma(1/sig,0.1,0.1,log=TRUE))
  lq1       <- sum(dgamma(cansig,aaa,bbb/sig,log=TRUE))
  lq2       <- sum(dgamma(sig,   aaa,bbb/cansig,log=TRUE))
  R         <- lp1-lp2+lq2-lq1
  if(log(runif(1))<R)
  {
    delta[l-1] <- cansig
    flag <- 1
  }
  return(flag)
}



#####################################Function################################################
  #' @title The function to fit image on image regression Y_i(s) = beta0(s) + beta1(s)X_i
  #' @description Takes the response variable (Y), explanatory variable (X) and the number of components
  #' and spits out the posterior samples of beta
  #' @references Roy et. al. (2019)
  #'     "Spatial shrinkage via the product independent Gaussian process prior" arXiv 1805.03240
  #'
  #' @param Y is response matrix with each column, representing vectorized 3-D images at each replication
  #' @param X is explanatory matrix with each column, representing vectorized image at each replication
  #' @param q is the number of components in PING
  #' @param n1 is the dimension along first direction
  #' @param n2 is the dimension along second direction
  #' @param n3 is the dimension along third direction
  #' @param Total_sample is the total number of iterations of MCMC
  #' @param thin is the thinning parameter of the MCMC samples
  #' @param jumpstart is the indicator variable if initialize with MCMC with an estimate using GP
  #' @param sbd is the initial step size to update PING prior in beta
  #' @param pri.mn is the prior mean of reparametrized Matern parameters
  #' @param pri.sd is the prior standard deviation of reparametrized Matern parameters


  #' @return image.scalar returns a list of the posterior samples of beta \cr
  #' \item{Beta_p}{The posterior samples of beta}
  #'
  #'
  #' @export
  #' @examples
#' n1       <- 20
#' n2       <- 20
#' n3       <- 20
#' n        <- n1*n2*n3
#' dimvec <- c(n1, n2, n3)
#'
#' theta  <- c(log(.08),log(0.90/0.10),log(10),0)
#' thetaA <- c(0,log(0.95/0.05),log(10),0)
#' thetaB <- c(0,log(0.95/0.05),log(10),0)
#' Sigma  <- matrix(c(0.5,-0.5,-0.5,1),2,2)
#'
#' mat    <- theta2mat(theta)
#' matA   <- theta2mat(thetaA)
#' matB   <- theta2mat(thetaB)
#'
#' delta <- homega3D(dimvec)
#'
#' specd0  <- spec_d_matern(delta,theta,dimvec)
#' specdA0 <- spec_d_matern(delta,thetaA,dimvec)
#' specdB <- spec_d_matern(delta,thetaB,dimvec)
#'
#' A1 <- rep(1:n2, each = n1)
#' A2 <- rep(1:n1, n2)
#' tempA <- cbind(A2, A1)
#' Ap <- matrix(rep(array(t(tempA)), n3), ncol=2, byrow = T)
#' Ap <- cbind(Ap, rep(1:n3, each=n1*n2))
#'
#' Ap2 <- Ap-matrix(c(n1*.3, n2*.5,n3*.7), nrow = nrow(Ap), 3, byrow=T)
#' Ap1 <- Ap-matrix(c(n1*.3, n2*.7,n3*.3), nrow = nrow(Ap), 3, byrow=T)
#' Ap3 <- Ap-matrix(c(n1*.7, n2*.3,n3*.7), nrow = nrow(Ap), 3, byrow=T)
#'
#'
#' d1 <- 2*exp(-4*rowSums(Ap1^2)/20)
#' d2 <- 2*exp(-1.5*rowSums(Ap2^2)/20)
#' d3 <- 2*exp(-4*rowSums(Ap3^2)/20)
#' d4 <- 2*exp(-4*rowSums((Ap-n1*.7)^2)/20)
#' d5 <- 2*exp(-4*rowSums((Ap-n1*.3)^2)/20)
#' Z1     <- ifelse(Ap[, 3]<n3/2,1,0)
#' Z2     <- 1-Z1
#'
#' #' Missing data locations
#'
#' miss  <- array(FALSE, dimvec)
#' miss[n1-1:buff+1,,]<- TRUE
#' miss[,n2-1:buff+1,]<- TRUE
#' miss[,,n3-1:buff+1]<- TRUE
#' miss[,1:buff,]<- TRUE
#' miss[1:buff,,]<- TRUE
#' miss[,,1:buff]<- TRUE
#'
#' m       <- 20    #' Number of subjects
#' RE      <- TRUE  #' Generate data with random effects?
#'
#'
#' dimvec <- c(n1,n2,n3)
#' n_spline <- 6
#' J <- n_spline^3
#'
#' X   <- 1:m
#' X <- (1:10-5.5)/4.5
#' X <- cbind(rep(1,m),X)
#' Beta <- matrix(0, n1*n2*n3, ncol(X))
#' M<-m
#'
#' MU_b  <- matrix(0,J,M)
#' tauQ  <- 1
#' init.theta=c(0,2,2,0)
#' theta <- matrix(init.theta, ncol = 4,nrow = (7),byrow=T)
#'
#'
#' B0  <- simulateMatern(specdA0,dimvec)
#' B1  <- d1 + d2 + d3 + d4 + d5
#' B1[which(B1<1e-1)]<- 0
#'
#' Ylist <- matrix(0, n, m)
#' for(t in 1:m){
#'   re         <- t(chol(Sigma))%*%rnorm(2)
#'   Ylist[, t] <- B0 + X[t, 2]*B1 + simulateMatern(specd0,dimvec)
#' }
#'
#' Y <- Ylist
#' fit <- image.scalar(Y, X, 5, 20, 20, 20,Total_sample = 200)
  image.scalar <- function(Y.o, X, q = 5, n1, n2, n3, thin = 1, Total_sample = 2000, jumpstart = 0, sdb = 2,
                           pri.mn=c(0,0,0,0), pri.sd=c(10,2,10,1)){

    X <- cbind(rep(1, length(X)), X)
    dimvec <- c(n1, n2, n3)

    delta <- homega3D(dimvec)

    n <- prod(dimvec)

    gout <- greal(c(n1, n2, n3))

    rid <- as.logical(gout$realindex)

    h.omega <- homega3D(c(n1, n2, n3))
    ch.omega <- which(h.omega <= quantile(h.omega, J/(n1*n2*n3)))

    realind <- array(0, c(n1, n2, n3))

    realind[1, 1, 1]  <- 1
    if(n1%%2==0){
      realind[(n1/2+1), 1, 1] <- 1
      if(n2%%2==0){
        realind[(n1/2+1), (n2/2+1), 1] <- 1
        realind[1, (n2/2+1), 1] <- 1
      }
      if(n3%%2==0){
        realind[(n1/2+1), (n2/2+1), (n3/2+1)] <- 1
        realind[1, (n2/2+1), (n3/2+1)] <- 1
        realind[(n1/2+1), 1, (n3/2+1)] <- 1
        realind[1, 1, (n3/2+1)]  <- 1
      }}
    realind <- as.logical(array(realind))

    #index of a 3D array

    A1 <- rep(1:n2, each = n1)
    A2 <- rep(1:n1, n2)
    tempA <- cbind(A2, A1)
    Ap <- matrix(rep(array(t(tempA)), n3), ncol=2, byrow = T)
    Ap <- cbind(Ap, rep(1:n3, each=n1*n2))

    L=1
    MHY=.01

    Y <- apply(Y.o, 2 ,function(x){convert1(array(x,dimvec), gout)})
    Betasp <- matrix(0, n1*n2*n3, ncol(X))

    CX <- crossprod(X)
    Betasp <- t(solve(CX)%*%crossprod(X,t(Y.o)))

    temp <- Betasp[, 2] #sqrt(abs(Betasp[, 2]))
    temp1 <- sign(temp)*(abs(temp))^(1/q)
    Betac <- matrix(rep(temp1, q), ncol = q)
    Beta <- t(solve(CX)%*%crossprod(X,t(Y)))

    SPECD <- spec_d_matern(h.omega,theta[1, ],dimvec, whichreal = realind)

    SPECDC <- mcmapply(2:(7), FUN=function(i){spec_d_matern(h.omega,theta[i, ],dimvec, whichreal = realind)})

    specd <- SPECD

    specd[realind] <- 2*specd[realind]

    Betacf1 <- apply(Betac, 2 ,function(x){convert1(array(x, dimvec), gout)})

    Betacf <- list()
    Betac <- list()
    for(i in 1:5){
      Betacf[[i]] <- array(Betacf1, dimvec)
      Betac[[i]] <- array(temp1, dimvec)
    }

    #MCMC
    Total_itr <- Total_sample + 2000
    itr = 0 + 2000 * (jumpstart == 0)
    if(q == 1){
      Total_itr <- Total_sample
      itr       <- 0
    }
    Beta1_p <- list()
    Betac_p <- list()
    acceptedthetano_p <- matrix(0, Total_itr, 3)
    accepteddeltamatno_p <- rep(0, Total_itr)
    accepteddeltano_p <- rep(0, Total_itr)

    tol=0.000001

    sdl1 <- sdl2 <- sdl3 <- 0.05
    tauQ <- 1
    MU <- rep(0, length(ch.omega))
    flag <- rep(0, 3)
    sd = sdb
    flagbeta2 <- 0
    pb <- txtProgressBar(min = itr, max = Total_itr, style = 3)
    c=0
    while(itr < Total_itr)
    {
      flag <- rep(0, 3)
      itr <- itr + 1

      fixedy <- matrix(0, nrow(Y), ncol(Y))

      fixedy[ - ch.omega, ] <- Y[ - ch.omega, ]

      fixedy[ch.omega, ] <- Y[ch.omega, ] - MU

      if(q == 1){
        Beta[, 2] <- array(updateBeta(2, fixedy, SPECDC[,2], Beta, SPECD, X, B, n))

        residy <- rowSums((fixedy - Beta%*%t(X))^2)

        ty <- cbind(residy, Beta^2)

        l=1
        n <- prod(dimvec)
        y <- ty[,l]
        speccur <- SPECD
        SPECDA <- speccur
        thetaA <- theta[l, ]
        cant     <- thetaA[-1] + rnorm(3,sd = sdl1) #MH[2]*tCthetaA%*%
        cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
        bb       <- sum(y/cansd)/2+.1
        cant1    <- -log(rgamma(1,M*n/2+.1,bb))
        cant     <- c(cant1,cant)
        cansd    <- exp(cant1)*cansd
        BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

        curll    <- -0.5*M*sum(log(speccur)) - 0.5*sum(y/speccur)+
          sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
          dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
        canll    <- -0.5*M*sum(log(cansd)) - 0.5*sum(y/cansd)+
          sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
          dgamma(exp(-cant[1]),.1,.1,log=TRUE)
        Q1       <- dgamma(exp(-thetaA[1]),M*n/2+.1,BB,log=TRUE)
        Q2       <- dgamma(exp(-cant[1]),M*n/2+.1,bb,log=TRUE)
        R        <- canll-curll+Q1-Q2
        if(!is.na(R)){if(log(runif(1))< R){
          flag[l] <- 1
          theta[l,]  <- cant
          SPECDA  <- cansd
          curll <- canll
        }}
        if(l>1){
          SPECDC[,l-1] <- SPECDA
        }
        if(l==1){
          SPECD <- SPECDA
        }

        for(l in 2){
          n <- prod(dimvec)
          y <- ty[,l]
          speccur <- SPECD
          if(l>1)
          {speccur <- SPECDC[,l-1]}
          SPECDA <- speccur
          thetaA <- theta[l, ]
          cant     <- thetaA[-1] + rnorm(3,sd = sdl2) #MH[2]*tCthetaA%*%
          cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
          bb       <- sum(y/cansd)/2+.1
          cant1    <- -log(rgamma(1,n/2+.1,bb))
          cant     <- c(cant1,cant)
          cansd    <- exp(cant1)*cansd
          BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

          curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[l] <- 1
            theta[l,]  <- cant
            SPECDA  <- cansd
            curll <- canll
          }}
          if(l>1){
            SPECDC[,l-1] <- SPECDA
          }
        }
        for(l in 3){
          n <- prod(dimvec)
          y <- ty[,l]
          speccur <- SPECD
          if(l>1)
          {speccur <- SPECDC[,l-1]}
          SPECDA <- speccur
          thetaA <- theta[l, ]
          cant     <- thetaA[-1] + rnorm(3,sd = sdl3) #MH[2]*tCthetaA%*%
          cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec,  whichreal = realind)
          bb       <- sum(y/cansd)/2+.1
          cant1    <- -log(rgamma(1,n/2+.1,bb))
          cant     <- c(cant1,cant)
          cansd    <- exp(cant1)*cansd
          BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

          curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[l] <- 1
            theta[l,]  <- cant
            SPECDA  <- cansd
            curll <- canll
          }}
          if(l>1){
            SPECDC[,l-1] <- SPECDA
          }
        }

        Betac <- array(convert1(array(Beta[,2], dimvec), gout, inv = T))

        theta_p[[itr]] <- theta

        acceptedthetano_p[itr, ] <- flag

        if(itr%%thin==0){
          Beta1_p[[itr/thin]] <- array(convert1(array(Beta[,1], dimvec), gout, inv = T))
          Betac_p[[itr/thin]] <- Betac
        }

        if(itr%%100 == 0){
            if(mean(acceptedthetano_p[1:itr,1]) > 0.45){sdl1 <- sdl1*1.2}
            if(mean(acceptedthetano_p[1:itr,1]) < 0.15){sdl1 <- sdl1*0.8}
            if(mean(acceptedthetano_p[1:itr,2]) > 0.45){sdl2 <- sdl2*1.2}
            if(mean(acceptedthetano_p[1:itr,2]) < 0.15){sdl2 <- sdl2*0.8}
            if(mean(acceptedthetano_p[1:itr,3]) > 0.45){sdl3 <- sdl3*1.2}
            if(mean(acceptedthetano_p[1:itr,3]) < 0.3){sdl3 <- sdl3*0.8}
          }
      }
      if(q > 1){
        if(itr<=2000){
          Beta[, 2] <- array(updateBeta(2, fixedy, SPECDC[,2], Beta, SPECD, X, B, n))

          residy <- rowSums((fixedy - Beta%*%t(X))^2)

          ty <- cbind(residy, Beta^2)

          l=1
          n <- prod(dimvec)
          y <- ty[,l]
          speccur <- SPECD
          SPECDA <- speccur
          thetaA <- theta[l, ]
          cant     <- thetaA[-1] + rnorm(3,sd = sdl1) #MH[2]*tCthetaA%*%
          cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
          bb       <- sum(y/cansd)/2+.1
          cant1    <- -log(rgamma(1,M*n/2+.1,bb))
          cant     <- c(cant1,cant)
          cansd    <- exp(cant1)*cansd
          BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

          curll    <- -0.5*M*sum(log(speccur)) - 0.5*sum(y/speccur)+
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- -0.5*M*sum(log(cansd)) - 0.5*sum(y/cansd)+
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),M*n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),M*n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[l] <- 1
            theta[l,]  <- cant
            SPECDA  <- cansd
            curll <- canll
          }}
          if(l>1){
            SPECDC[,l-1] <- SPECDA
          }
          if(l==1){
            SPECD <- SPECDA
          }

          for(l in 2){
            n <- prod(dimvec)
            y <- ty[,l]
            speccur <- SPECD
            if(l>1)
            {speccur <- SPECDC[,l-1]}
            SPECDA <- speccur
            thetaA <- theta[l, ]
            cant     <- thetaA[-1] + rnorm(3,sd = sdl2) #MH[2]*tCthetaA%*%
            cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
            bb       <- sum(y/cansd)/2+.1
            cant1    <- -log(rgamma(1,n/2+.1,bb))
            cant     <- c(cant1,cant)
            cansd    <- exp(cant1)*cansd
            BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

            curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
              sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
            canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
              sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-cant[1]),.1,.1,log=TRUE)
            Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
            Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
            R        <- canll-curll+Q1-Q2
            if(!is.na(R)){if(log(runif(1))< R){
              flag[l] <- 1
              theta[l,]  <- cant
              SPECDA  <- cansd
              curll <- canll
            }}
            if(l>1){
              SPECDC[,l-1] <- SPECDA
            }
          }
          for(l in 3){
            n <- prod(dimvec)
            y <- ty[,l]
            speccur <- SPECD
            if(l>1)
            {speccur <- SPECDC[,l-1]}
            SPECDA <- speccur
            thetaA <- theta[l, ]
            cant     <- thetaA[-1] + rnorm(3,sd = sdl3) #MH[2]*tCthetaA%*%
            cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec,  whichreal = realind)
            bb       <- sum(y/cansd)/2+.1
            cant1    <- -log(rgamma(1,n/2+.1,bb))
            cant     <- c(cant1,cant)
            cansd    <- exp(cant1)*cansd
            BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

            curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
              sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
            canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
              sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-cant[1]),.1,.1,log=TRUE)
            Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
            Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
            R        <- canll-curll+Q1-Q2
            if(!is.na(R)){if(log(runif(1))< R){
              flag[l] <- 1
              theta[l,]  <- cant
              SPECDA  <- cansd
              curll <- canll
            }}
            if(l>1){
              SPECDC[,l-1] <- SPECDA
            }
          }

          Betac <- array(convert1(array(Beta[,2], dimvec), gout, inv = T))

          theta_p[[itr]] <- theta

          acceptedthetano_p[itr, ] <- flag

          if(itr>1500)
            Beta2_p[[itr-1500]] <- Beta[, 2]
        }

        if(itr==2000){
          Beta2 <- Reduce('+', Beta2_p)/500
          Betac <- array(convert1(array(Beta2, dimvec), gout, inv = T))
          theta[3, 1] <- theta[3, 1]
          for(k in 1:q){
            theta[(2+k), ] <- theta[3, ]
          }
          temp1 <- sign(Betac)*(abs(Betac))^(1/q)
          Betac <- matrix(rep(temp1, q), ncol = q)
          SPECDC <- mcmapply(2:(q+2), FUN=function(i){spec_d_matern(h.omega,theta[i, ],dimvec, whichreal = realind)})
        }


        if(itr>2000){
          for(i in 1:q){
            temp <- tcrossprod(Betacf[[i]],X[,2])
            inter <- Y - Beta %*% t(X) + temp
            gen <- array(updateBeta(2, inter, SPECDC[,i+1], matrix(0, n, 2), SPECD, X, B, n))
            gen11 <- array(gen, dimvec)
            up <- convert1(gen11, gout, inv = T)

            prop <- sd
            nrm <- as.numeric(sqrt(crossprod(up - Betac[[ i]])))
            up <- Betac[[i]] + min(nrm, sd)*(up - Betac[[i]])/nrm
            upf <- Betacf[[i]] + min(nrm, sd)*(gen11 - Betacf[[i]])/nrm

            Betacan <- array(convert1(up*Reduce("*", Betac[c(1:q)[-i]]), gout))

            diff1 <- rowSums((Y - Beta %*% t(X))^2) - rowSums((Y - tcrossprod(cbind(Beta[, 1],Betacan), X))^2)
            diff2 <- Betacf[[i]]^2 - upf^2

            R <- sum(diff1/SPECD + diff2/SPECDC[, i+1])

            if(rbinom(1,1,min(exp(R/2),1))){
              c=c+1
              Betac[[i]] <- up
              Betacf[[i]] <- upf
              Beta[, 2] <- Betacan
              Beta[, 1] <- array(updateBeta(1, fixedy, SPECDC[,1], Beta, SPECD, X, B, n))
            }
          }

          if(itr%%100==0){
            it=itr-2000
            if(c/(q*it) > 0.70){sd <- sd * (1+5e-1)}
            if(c/(q*it) < 0.55){sd <- sd * (1-5e-1)}
          }
          if((itr-2000)%%thin == 0){
            Betac_p[[(itr-2000)/thin]] <- Reduce("*", Betac)
            Beta1_p[[(itr-2000)/thin]] <- array(convert1(array(Beta[, 1], dimvec), gout, inv = T))
          }

          residy <- rowSums((fixedy - Beta%*%t(X))^2)

          ty <- cbind(residy, Beta[,1]^2, Betacf[[1]]^2, Betacf[[2]]^2, Betacf[[3]]^2, Betacf[[4]]^2, Betacf[[5]]^2)

          l=1
          n <- prod(dimvec)
          y <- ty[,l]
          speccur <- SPECD
          SPECDA <- speccur
          thetaA <- theta[l, ]
          cant     <- thetaA[-1] + rnorm(3,sd = sdl1) #MH[2]*tCthetaA%*%
          cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
          bb       <- sum(y/cansd)/2+.1
          cant1    <- -log(rgamma(1,M*n/2+.1,bb))
          cant     <- c(cant1,cant)
          cansd    <- exp(cant1)*cansd
          BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

          curll    <- -0.5*M*sum(log(speccur)) - 0.5*sum(y/speccur)+
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- -0.5*M*sum(log(cansd)) - 0.5*sum(y/cansd)+
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),M*n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),M*n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[l] <- 1
            theta[l,]  <- cant
            SPECDA  <- cansd
            curll <- canll
          }}
          if(l>1){
            SPECDC[,l-1] <- SPECDA
          }
          if(l==1){
            SPECD <- SPECDA
          }

          l=2
          n <- prod(dimvec)
          y <- ty[,l]
          speccur <- SPECD
          if(l>1)
          {speccur <- SPECDC[,l-1]}
          SPECDA <- speccur
          thetaA <- theta[l, ]
          cant     <- thetaA[-1] + rnorm(3,sd = sdl2)
          cansd    <- spec_d_matern(h.omega,c(0,cant),dimvec, whichreal = realind)
          bb       <- sum(y/cansd)/2+.1
          cant1    <- -log(rgamma(1,n/2+.1,bb))
          cant     <- c(cant1,cant)
          cansd    <- exp(cant1)*cansd
          BB       <- exp(thetaA[1])*sum(y/speccur)/2+.1

          curll    <- -0.5*sum(log(speccur)) - 0.5*sum(y/speccur)+
            sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
          canll    <- -0.5*sum(log(cansd)) - 0.5*sum(y/cansd)+
            sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
            dgamma(exp(-cant[1]),.1,.1,log=TRUE)
          Q1       <- dgamma(exp(-thetaA[1]),n/2+.1,BB,log=TRUE)
          Q2       <- dgamma(exp(-cant[1]),n/2+.1,bb,log=TRUE)
          R        <- canll-curll+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[l] <- 1
            theta[l,]  <- cant
            SPECDA  <- cansd
            curll <- canll
          }}
          if(l>1){
            SPECDC[,l-1] <- SPECDA
          }

          l=3
          n <- prod(dimvec)
          y <- ty[,3:(q+2)]
          speccur <- SPECDC[,2:(q+1)]
          thetaA <- theta[3:(q+2), ]
          cantc     <- thetaA[1,-1] + rnorm(3,sd = sdl3)
          cansd1 <- matrix(0, n, q)
          cansd    <- spec_d_matern(h.omega,c(0,cantc),dimvec, whichreal = realind)
          bb <- rep(0, q)
          cant <- rep(0, q)
          cansd1 <- matrix(0, length(cansd), q)
          for(k in 1:q){
            bb[k] <- sum(y[, k]/cansd)/2+.1
            cant1    <- -log(rgamma(1,n/2+.1,bb[1]))*(q==1)+0
            cant11     <- c(cant1,cantc)
            cansd1[, q]    <- exp(cant1)*cansd
          }

          BB <- rep(0, q)
          curll <- rep(0, q)
          canll <- rep(0, q)

          for(k in 1:q){
            cant1    <- -log(rgamma(1,n/2+.1,bb[1]))*(q==1)+0
            BB[k]    <- exp(thetaA[k, 1])*sum(y[, k]/speccur[, k])/2+.1
            curll[k] <- -0.5*sum(log(speccur[,k])) - 0.5*sum(y[,k]/speccur[,k])+
              dgamma(exp(-thetaA[k,1]),.1,.1,log=TRUE)
            canll[k] <- -0.5*sum(log(cansd1[, k])) - 0.5*sum(y[, k]/cansd1[, k])+
              dgamma(exp(-cant1),.1,.1,log=TRUE)
          }

          curll[1] <- curll[1] + sum(dnorm(thetaA[1,-c(1)],pri.mn[-c(1)],pri.sd[-c(1)],log=TRUE))
          canll[1] <- canll[1] + sum(dnorm(cantc,pri.mn[-c(1)],pri.sd[-c(1)],log=TRUE))

          Q1       <- (dgamma(exp(-thetaA[1,1]),n/2+.1,BB[1],log=TRUE))

          Q2       <- dgamma(exp(-cant1),n/2+.1,bb[1],log=TRUE)

          R        <- sum(canll)-sum(curll)+Q1-Q2
          if(!is.na(R)){if(log(runif(1))< R){
            flag[l] <- 1
            for(k in 1:q){
              theta[(2+k), ]  <- cant11[, k]
              SPECDC[, (k+1)] <- cansd1[, k]
            }
          }}

        }
        acceptedthetano_p[itr, ] <- flag

        specd <- SPECD

        specd[realind] <- 2*specd[realind]



        if(itr%%100 == 0){
          if(itr <= 2000){
            if(mean(acceptedthetano_p[1:itr,1]) > 0.45){sdl1 <- sdl1*1.2}
            if(mean(acceptedthetano_p[1:itr,1]) < 0.15){sdl1 <- sdl1*0.8}
            if(mean(acceptedthetano_p[1:itr,2]) > 0.45){sdl2 <- sdl2*1.2}
            if(mean(acceptedthetano_p[1:itr,2]) < 0.15){sdl2 <- sdl2*0.8}
            if(mean(acceptedthetano_p[1:itr,3]) > 0.45){sdl3 <- sdl3*1.2}
            if(mean(acceptedthetano_p[1:itr,3]) < 0.3){sdl3 <- sdl3*0.8}
          }

          if(itr > 2000){
            if(mean(acceptedthetano_p[2001:itr,1]) > 0.45){sdl1 <- sdl1*1.2}
            if(mean(acceptedthetano_p[2001:itr,1]) < 0.15){sdl1 <- sdl1*0.8}
            if(mean(acceptedthetano_p[2001:itr,2]) > 0.45){sdl2 <- sdl2*1.2}
            if(mean(acceptedthetano_p[2001:itr,2]) < 0.15){sdl2 <- sdl2*0.8}
            if(mean(acceptedthetano_p[2001:itr,3]) > 0.4){sdl3 <- sdl3*1.2}
            if(mean(acceptedthetano_p[2001:itr,3]) < 0.2){sdl3 <- sdl3*0.8}
          }
        }
      }

      Sys.sleep(0.1)
      # update progress bar
      setTxtProgressBar(pb, itr)
    }
    close(pb)
    return(list(beta0 = Beta1_p, beta1 = Betac_p))
  }
