library(mvtnorm)
library(matrixStats)
library(geoR)

# Transform that to matern parameters
theta2mat <- function(theta,nugget=TRUE){
  c(exp(theta[1]),
    ifelse(nugget,1/(1+exp(-theta[2])),1),
    exp(theta[3]),
    exp(theta[4]))
}

# Transform matern parameters to theta
mat2theta <- function(mat,nugget=TRUE){
  c(log(mat[1]),
    ifelse(nugget,log(mat[2]/(1-mat[2])),Inf),
    log(mat[3]),
    log(mat[4]))
}

simulateMatern <- function(theta, d){
  thetan <- rep(0, 4)
  temp <- theta2mat(theta)
  thetan[1] <- temp[1]*(1-temp[2])
  thetan[2] <- temp[1]*temp[2]
  thetan[3:4] <- temp[3:4]
  Var <- thetan[2] * matern(d, thetan[3], thetan[4])
  diag(Var) <- diag(Var) + thetan[1]
  ret <- rmvnorm(1, sigma = Var)
  return(ret)
}

Maternvar <- function(theta, d){
  thetan <- rep(0, 4)
  temp <- theta2mat(theta)
  thetan[1] <- temp[1] * (1 -temp[2])
  thetan[2] <- temp[2] * temp[1]
  thetan[3:4] <- temp[3:4]
  Var <- thetan[2] * matern(d, thetan[3], thetan[4])
  diag(Var) <- diag(Var) + thetan[1]
  return(Var)
}

updateBeta <- function(l, y, IVarc, Beta, IVare, X, B =  NULL){
  if(is.null(B)){B <- rep(1, n)}
  mean <- apply(X, 3, function(x){rowSums(Beta[, c(2:11)[-l]]*x[, -l])})
  Beta.mean <- rowSums(sapply(1:m, function(k){diag((X[, l,k])*(B))%*%IVare%*%(y[, k]-mean[, k])})) #rowSums((y - mean)*X[, l,])*(B)
  Beta.ivar <- lapply(1:m, function(k){diag((X[,l,k])*B)%*%IVare%*%diag((X[,l,k])*B)})
  Beta.ivar <- Reduce('+', Beta.ivar)+ IVarc
  Beta.var <- solve(Beta.ivar)
  Beta.var <- (Beta.var + t(Beta.var))/2
  Beta.mean <- Beta.var %*% Beta.mean
  gen <- rmvnorm(1, Beta.mean, Beta.var)
  return(gen)
}


######################################Function#######################################
      #' @title The function to fit image on image regression Y_i = X_i(s)'beta(s)
      #' @description Takes the response variable (Y), explanatory variable (X) and the number of components
      #' and spits out the posterior samples of beta
      #' @references Roy et. al. (2019)
      #'     "Spatial shrinkage via the product independent Gaussian process prior" arXiv 1805.03240
      #'
      #' @param Y is the response vector
      #' @param X is explanatory matrix with each row, representing vectorized image at each replication
      #' @param q is the number of components in PING
      #' @param Total_sample is the total number of iterations of MCMC
      #' @param thin is the thinning parameter of the MCMC samples
      #' @param pri.mn is the prior mean of reparametrized Matern parameters
      #' @param pri.sd is the prior standard deviation of reparametrized Matern parameters


      #' @return scalar.image returns a list of the posterior samples of beta \cr
      #' \item{Beta_p}{The posterior samples of beta}
      #' #' @export
      #' @examples
      #'     #' n1 <- 20
#' n2 <- 20
#' n <- 100
#' set.seed(8)
#' A1 <- rep(1:n2, each = n1)
#' A2 <- rep(1:n1, n2)
#' tempA <- cbind(A2, A1)
#'
#' Ap <- tempA
#'
#'
#' m       <- 20
#' RE      <- TRUE
#'
#'
#' L=1
#' MHY=.01
#'
#' X <- matrix(0, n, n1*n2)
#'
#' loc <- Ap
#' dis <- as.matrix(dist(loc))
#' nux <- vx[nuind]
#' xvar <- Exponential(dis, range = nux)
#'
#' for(i in 1:n){
#'   X[i, ] <- rmvnorm(1,sigma = xvar)
#' }
#'
#' h <- 2
#' u <- matrix(runif(h*2), nrow=2)
#' if(h == 2){
#'   d <- 1*exp(-5*rowSums((Ap-matrix(c(n1*u[1,1], n2*u[1,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50) + 1*exp(-5*rowSums((Ap-matrix(c(n1*u[2,1], n2*u[2,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50)
#' }
#'
#' h <- 5
#' u <- matrix(c(.2,.8,.2,.8,.5,.8,.2,.2,.8,.5), nrow=5)
#'
#' d <- 0
#' for(i in 1:5){
#'   d <- d + 2*exp(-20*rowSums((Ap-matrix(c(n1*u[i,1], n2*u[i,2]), nrow = nrow(Ap), 2, byrow=T))^2)/50)
#' }
#'
#' B0  <- d
#' B0[which(B0<1e-1)]<- 0
#' sigma0 <- var[vind]
#'
#' Y <- rnorm(n, mean = X%*%B0, sd=sigma0)
#' fit <- scalar.image(Y, X, Total_sample = 200)
      scalar.image <- function(Y, X, q = 5, Total_sample, thin = 1, pri.mn=c(0,0,0,0), pri.sd=c(10,2,10,1)){
        m <- length(Y)

        init.theta= c(0,2,2,0)
        theta <- init.theta

        sigma = 1

        isdmat <- solve(Maternvar(theta, dis))

        Beta.mean <- t(X) %*% Y / sigma^2
        Beta.ivar <- t(X) %*% X / sigma^2 + isdmat
        Beta.var <- solve(Beta.ivar)
        Beta.var <- (Beta.var + t(Beta.var))/2
        Beta.mean <- Beta.var %*% Beta.mean
        temp <- rmvnorm(1, Beta.mean, Beta.var)
        temp1 <- sign(temp)*(abs(temp))^(1/q)
        Betac <- matrix(rep(temp1, q), ncol = q)
        Beta <- array(temp)

        Total_itr <- Total_sample
        itr = 0
        Beta_p <- list()
        acceptedthetano_p <- rep(0, Total_itr)

        tol=0.000001

        sdl <- 1e-1
        alpha0 <- 0.1
        beta0 <- 0.1
        pb <- txtProgressBar(min = itr, max = Total_itr, style = 3)
        while(itr < Total_itr){
          itr <- itr + 1
          al <- alpha0 + n / 2
          be <- beta0 + sum((Y-X%*%Beta) ^ 2) / 2
          sigma <- sqrt(1 / rgamma(1, al, be))

          if(q>1){
            for(k in 1:q){
              B <- Betac[, -k]
              if(q > 2){
                B <- rowProds(Betac[, -k])
              }
              ivar <- isdmat*(k==1) + isdmat*exp(theta[1])*(k>1)
              X1 <- X*matrix(B, n, n1*n2, byrow = T)
              Beta.mean <- t(X1) %*% Y / sigma^2
              Beta.ivar <- t(X1) %*% X1 / sigma^2 + ivar
              Beta.var <- solve(Beta.ivar)
              Beta.var <- (Beta.var + t(Beta.var))/2
              Beta.mean <- Beta.var %*% Beta.mean
              Betac[, k] <- rmvnorm(1, Beta.mean, Beta.var)
            }
            temp <- array(rowProds(Betac))
            Beta <- temp

            thetaA <- theta
            cant <- rep(0, 4)
            cant[-1]     <- thetaA[-1] + rnorm(3,sd = sdl) #MH[2]*tCthetaA%*%
            cansd    <- solve(Maternvar(cant, dis))
            psd <- isdmat    #Maternvar(thetaA, dis)
            y   <-     Betac
            bb       <- (t(y[, 1])%*%(cansd)%*%(y[, 1]))/2+.1
            cant1    <- -log(rgamma(1,(n1*n2)/2+.1,bb))
            cant[1]  <- cant1
            cansd    <- cansd/exp(cant1)
            BB       <- exp(thetaA[1])*(t(y[, 1])%*%(psd)%*%(y[, 1]))/2+.1

            term1    <- t(y[, 2])%*%psd%*%y[, 2]*exp(thetaA[1]) / 2

            if(q > 2){
              term1    <- sum(apply(y[, 2:q], 2, function(x){t(x)%*%psd%*%x*exp(thetaA[1])}))/2
            }

            term2    <- t(y[, 2])%*%cansd%*%y[, 2]*exp(cant[1]) / 2

            if(q > 2){
              term2    <- sum(apply(y[, 2:q], 2, function(x){t(x)%*%cansd%*%x*exp(cant[1])}))/2
            }

            curll    <- 0.5*as.numeric(determinant(psd)$modulus) + 0.5*(q-1)*as.numeric(determinant(psd*exp(thetaA[1]))$modulus)-
              (t(y[, 1])%*%(psd)%*%(y[, 1]))/2 - term1 +
              sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
            canll    <- 0.5*as.numeric(determinant(cansd)$modulus) + 0.5*(q-1)*as.numeric(determinant(cansd*exp(cant1))$modulus)-
              (t(y[, 1])%*%(cansd)%*%(y[, 1]))/2 - term2 +
              sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-cant[1]),.1,.1,log=TRUE)
            Q1       <- dgamma(exp(-thetaA[1]),(n1*n2)/2+.1,BB,log=TRUE)
            Q2       <- dgamma(exp(-cant[1]),(n1*n2)/2+.1,bb,log=TRUE)
            R        <- canll-curll+Q1-Q2
            if(!is.na(R)){if(log(runif(1))< R){
              acceptedthetano_p[itr] <- 1
              theta  <- cant
              isdmat  <- cansd
            }}
          }

          if(q==1){
            Beta.mean <- t(X) %*% Y / sigma^2
            Beta.ivar <- t(X) %*% X / sigma^2 + isdmat
            Beta.var <- solve(Beta.ivar)
            Beta.var <- (Beta.var + t(Beta.var))/2
            Beta.mean <- Beta.var %*% Beta.mean
            temp <- array(rmvnorm(1, Beta.mean, Beta.var))
            Beta <- temp

            thetaA <- theta
            cant <- rep(0, 4)
            cant[-1]     <- thetaA[-1] + rnorm(3,sd = sdl)
            cansd    <- solve(Maternvar(cant, dis))
            psd <- isdmat
            y <-     Beta
            bb       <- (t(y)%*%(cansd)%*%(y))/2+.1
            cant1    <- -log(rgamma(1,(n1*n2)/2+.1,bb))
            cant[1]  <- cant1
            cansd    <- cansd/exp(cant1)
            BB       <- exp(thetaA[1])*(t(y)%*%(psd)%*%(y))/2+.1

            curll    <- 0.5*as.numeric(determinant(psd)$modulus) - (t(y)%*%(psd)%*%(y))/2 +
              sum(dnorm(thetaA[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-thetaA[1]),.1,.1,log=TRUE)
            canll    <- 0.5*as.numeric(determinant(cansd)$modulus) - (t(y)%*%(cansd)%*%(y))/2 +
              sum(dnorm(cant[-1],pri.mn[-1],pri.sd[-1],log=TRUE))+
              dgamma(exp(-cant[1]),.1,.1,log=TRUE)
            Q1       <- dgamma(exp(-thetaA[1]),(n1*n2)/2+.1,BB,log=TRUE)
            Q2       <- dgamma(exp(-cant[1]),(n1*n2)/2+.1,bb,log=TRUE)
            R        <- canll-curll+Q1-Q2
            if(!is.na(R)){if(log(runif(1))< R){
              acceptedthetano_p[itr] <- 1
              theta  <- cant
              isdmat  <- cansd
            }}
          }

          if(itr%%thin == 0){
            Beta_p[[itr/thin]] <- Beta
          }

          if(itr %% 100 == 0){
            if(mean(acceptedthetano_p[1:itr]) > 0.45){sdl <- sdl*1.2}
            if(mean(acceptedthetano_p[1:itr]) < 0.3){sdl <- sdl*0.8}
          }
          Sys.sleep(0.1)
          # update progress bar
          setTxtProgressBar(pb, itr)
        }
        close(pb)
        Beta_p
        return(Beta_p)
      }
